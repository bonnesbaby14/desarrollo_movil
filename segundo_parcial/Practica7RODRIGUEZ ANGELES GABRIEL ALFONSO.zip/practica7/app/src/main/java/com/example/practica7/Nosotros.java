package com.example.practica7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Nosotros extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nosotros);
    }
}